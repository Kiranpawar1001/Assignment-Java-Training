package com.example.orderservice.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Order")
public class Order {
	
	int oid;
	int cid;
	String productName;
	
        double price;

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(int oid, int cid, String productName, double price) {
		super();
		this.oid = oid;
		this.cid = cid;
		this.productName = productName;
		this.price = price;
	}

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	
	

}
