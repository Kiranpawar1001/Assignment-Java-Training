package com.example.customerserive.model;

import javax.persistence.Id;

public class OrderDto {
	
	int oid;
	
	int cid;
	
	String prodname;
	
	double price;

	public OrderDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderDto(int oid, int cid, String prodname, double price) {
		super();
		this.oid = oid;
		this.cid = cid;
		this.prodname = prodname;
		this.price = price;
	}

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getProdname() {
		return pname;
	}

	public void setPname(String prodname) {
		this.prodname = prodname;
	}

	public doublegetPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

}
