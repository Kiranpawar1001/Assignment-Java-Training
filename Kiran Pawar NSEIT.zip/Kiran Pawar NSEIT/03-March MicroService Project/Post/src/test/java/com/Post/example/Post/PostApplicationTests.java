package com.Post.example.Post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostApplicationTests {

	@Test
	void contextLoads() {
	}

}
