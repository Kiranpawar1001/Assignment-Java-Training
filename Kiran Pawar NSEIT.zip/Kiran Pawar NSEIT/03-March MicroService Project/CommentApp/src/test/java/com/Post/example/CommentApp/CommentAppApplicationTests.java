package com.Post.example.CommentApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
