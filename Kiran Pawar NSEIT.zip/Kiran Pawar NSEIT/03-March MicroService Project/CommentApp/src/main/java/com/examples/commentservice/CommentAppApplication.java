package com.examples.commentservice;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.examples.commentservice")
public class CommentAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommentAppApplication.class, args);
	}
}

